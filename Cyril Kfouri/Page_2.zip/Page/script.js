$(document).ready(function(){
    $(".nav-tabs a").click(function(){
      $(this).tab('show');
    });

    $(".carousel-buttons button").click(function(){
      var index = $(this).text() - 1; 
      $('#myCarousel').carousel(index);
    });
  });